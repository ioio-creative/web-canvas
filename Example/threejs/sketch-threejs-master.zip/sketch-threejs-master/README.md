# ![sketch of three.js](http://ykob.github.io/sketch-threejs/img/common/ogp_common.jpg)

Interactive sketches made with three.js.  
https://ykob.github.io/sketch-threejs/

## License

Copyright (c) 2017 Yoichi Kobayashi  
Released under the MIT license  
http://opensource.org/licenses/mit-license.php

## Misc

Follow Yoichi Kobayashi: [Web](http://www.tplh.net/), [Twitter](https://twitter.com/ykob0123)
