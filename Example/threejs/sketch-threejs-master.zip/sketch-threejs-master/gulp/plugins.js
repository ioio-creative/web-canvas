module.exports = require('gulp-load-plugins')();
